package com.example.mostrardatos

class CentroComputo {
}