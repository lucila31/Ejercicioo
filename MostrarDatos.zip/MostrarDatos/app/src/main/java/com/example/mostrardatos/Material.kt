package com.example.mostrardatos

class Material(idMaterial:String, nombreM:String, cantidad:Int ){
    private var idMaterial=idMaterial
    private var nombreM=nombreM
    private var cantidad=cantidad

    fun setNombre(nom: String){
        nombreM = nom
    }

    fun getNombre(): String{
        return nombreM
    }
    fun setId(idM: String){
        idMaterial = idM
    }

    fun getId(): String{
        return idMaterial
    }
    fun setCantidad(c: Int){
        cantidad=c
    }
    fun getCantidad(): Int{
        return  cantidad
    }
}