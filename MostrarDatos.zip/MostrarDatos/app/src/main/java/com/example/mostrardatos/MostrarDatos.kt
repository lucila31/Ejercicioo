package com.example.mostrardatos

fun main(args: Array<String>) {
    var nombre = ""
    var Apellidomat = ""
    var Apellidopat = ""
    var ncontrol = ""
    var carrera = ""
    var idPersonal = ""
    var nombrep = ""

    var ObjAlumno: Alumno = Alumno(ncontrol, nombre, Apellidopat, Apellidomat, carrera)


    print("Ingrese Numero de Control: ")
    ncontrol = readLine().toString()
    print("Ingresar Nombre: ")
    nombre = readLine().toString()
    print("Ingrese Apellido Paterno: ")
    Apellidopat = readLine().toString()
    print("Ingrese su Apellido Materno: ")
    Apellidomat = readLine().toString()
    print("Ingrese su carrera")
    carrera = readLine().toString()

    ObjAlumno.setNombre(nombre)
    ObjAlumno.setApellidopat(Apellidopat)
    ObjAlumno.setApellidomat(Apellidomat)
    ObjAlumno.setNControl(ncontrol)
    ObjAlumno.setCarrera(carrera)




    var NombreArea = ""
    var objArea: Area = Area(NombreArea)
    var objPersonal: Personal = Personal(idPersonal, nombrep)
    print("Igrese el nombre de Area prestada: ")
    NombreArea = readLine().toString()
    var NombreM = ""
    when (NombreArea) {
        "CENTRO DE COMPUTO" -> {
            objArea.setNombreAre(NombreArea)
            print("INGRESE EL MATERIAL SOLICITADO : ")
            NombreM = readLine().toString()
            when (NombreM) {
                "USB" -> {
                    var idmaterial = ""
                    var cantidad = 0
                    var objmaterial: Material = Material(idmaterial, NombreM, cantidad)
                    print(" INGRESE EL ID DEL MATERIAL: ")
                    idmaterial = readLine().toString()
                    print("INGRESE LA CANTIDAD:  ")
                    cantidad = readLine()!!.toInt()
                    print("INGRESE EL NOMBRE DEL ENCARGADO :")
                    nombrep = readLine().toString()
                    print("INGRESE ID DEL PERSONAL :")
                    idPersonal= readLine().toString()
                    objmaterial.setCantidad(cantidad)
                    objmaterial.setId(idmaterial)
                    objmaterial.setNombre(NombreM)
                    objPersonal.setNombre(nombrep)
                    objPersonal.setId(idPersonal)
                    println(" \n El NUMERO DE CONTROL:  ${ObjAlumno.getNControl()}  \nNOMBRE DEL ALUMNO:  ${ObjAlumno.getNombre()}  \nAPELLIDO PATERNO: ${ObjAlumno.getApellidopat()} \nAPELLIDO MATERNO  : ${ObjAlumno.getApellidomat()} \nCARRERA :${ObjAlumno.getCarrera()} \nNOMBRE DEL AREA : ${objArea.getNombreArea()} \nIDpersonal: ${objPersonal.getId()} \nNombre del area del encargado: ${objPersonal.getNombre()} \nNombre Material : ${objmaterial.getNombre()}  \nCantidad Material: ${objmaterial.getCantidad()}")


                }
                "DISCO DUROS" -> {
                    var idmaterial = ""
                    var cantidad = 0
                    var objmaterial: Material = Material(idmaterial, NombreM, cantidad)
                    print(" INGRESE EL ID DEL MATERIAL: ")
                    idmaterial = readLine().toString()
                    print("INGRESE LA CANTIDAD:  ")
                    cantidad = readLine()!!.toInt()
                    print("INGRESE EL NOMBRE DEL ENCARGADO :")
                    nombrep = readLine().toString()
                    print("INGRESE ID DEL PERSONAL :")
                    idPersonal= readLine().toString()
                    objmaterial.setCantidad(cantidad)
                    objmaterial.setId(idmaterial)
                    objmaterial.setNombre(NombreM)
                    objPersonal.setNombre(nombrep)
                    objPersonal.setId(idPersonal)
                    println(" \n El NUMERO DE CONTROL:  ${ObjAlumno.getNControl()}  \nNOMBRE DEL ALUMNO:  ${ObjAlumno.getNombre()}  \nAPELLIDO PATERNO: ${ObjAlumno.getApellidopat()} \nAPELLIDO MATERNO  : ${ObjAlumno.getApellidomat()} \nCARRERA :${ObjAlumno.getCarrera()} \nNOMBRE DEL AREA : ${objArea.getNombreArea()} \nIDpersonal: ${objPersonal.getId()} \nNombre del area del encargado: ${objPersonal.getNombre()} \nNombre Material : ${objmaterial.getNombre()}  \nCantidad Material: ${objmaterial.getCantidad()}")

                }
                "CANONES" -> {
                    var idmaterial = ""
                    var cantidad = 0
                    var objmaterial: Material = Material(idmaterial, NombreM, cantidad)
                    print(" INGRESE EL ID DEL MATERIAL: ")
                    idmaterial = readLine().toString()
                    print("INGRESE LA CANTIDAD:  ")
                    cantidad = readLine()!!.toInt()
                    print("INGRESE EL NOMBRE DEL ENCARGADO :")
                    nombrep = readLine().toString()
                    print("INGRESE ID DEL PERSONAL :")
                    idPersonal= readLine().toString()
                    objmaterial.setCantidad(cantidad)
                    objmaterial.setId(idmaterial)
                    objmaterial.setNombre(NombreM)
                    objPersonal.setNombre(nombrep)
                    objPersonal.setId(idPersonal)
                    println(" \n El NUMERO DE CONTROL:  ${ObjAlumno.getNControl()}  \nNOMBRE DEL ALUMNO:  ${ObjAlumno.getNombre()}  \nAPELLIDO PATERNO: ${ObjAlumno.getApellidopat()} \nAPELLIDO MATERNO  : ${ObjAlumno.getApellidomat()} \nCARRERA :${ObjAlumno.getCarrera()} \nNOMBRE DEL AREA : ${objArea.getNombreArea()} \nIDpersonal: ${objPersonal.getId()} \nNombre del area del encargado: ${objPersonal.getNombre()} \nNombre Material : ${objmaterial.getNombre()}  \nCantidad Material: ${objmaterial.getCantidad()}")

                }

                "MEMORIAS" -> {
                    var idmaterial = ""
                    var cantidad = 0
                    var objmaterial: Material = Material(idmaterial, NombreM, cantidad)
                    print(" INGRESE EL ID DEL MATERIAL: ")
                    idmaterial = readLine().toString()
                    print("INGRESE LA CANTIDAD:  ")
                    cantidad = readLine()!!.toInt()
                    print("INGRESE EL NOMBRE DEL ENCARGADO :")
                    nombrep = readLine().toString()
                    print("INGRESE ID DEL PERSONAL :")
                    idPersonal= readLine().toString()
                    objmaterial.setCantidad(cantidad)
                    objmaterial.setId(idmaterial)
                    objmaterial.setNombre(NombreM)
                    objPersonal.setNombre(nombrep)
                    objPersonal.setId(idPersonal)
                    println(" \n El NUMERO DE CONTROL:  ${ObjAlumno.getNControl()}  \nNOMBRE DEL ALUMNO:  ${ObjAlumno.getNombre()}  \nAPELLIDO PATERNO: ${ObjAlumno.getApellidopat()} \nAPELLIDO MATERNO  : ${ObjAlumno.getApellidomat()} \nCARRERA :${ObjAlumno.getCarrera()} \nNOMBRE DEL AREA : ${objArea.getNombreArea()} \nIDpersonal: ${objPersonal.getId()} \nNombre del area del encargado: ${objPersonal.getNombre()} \nNombre Material : ${objmaterial.getNombre()}  \nCantidad Material: ${objmaterial.getCantidad()}")

                }
            }

        }

        "BIBLIOTECA" -> {
            objArea.setNombreAre(NombreArea)
            print("INGRESE EL MATERIAL SOLICITADO : ")
            NombreM = readLine().toString()
            when (NombreM) {
                "LIBROS" -> {
                    var idmaterial = ""
                    var cantidad = 0
                    var objmaterial: Material = Material(idmaterial, NombreM, cantidad)
                    print(" INGRESE EL ID DEL MATERIAL: ")
                    idmaterial = readLine().toString()
                    print("INGRESE LA CANTIDAD:  ")
                    cantidad = readLine()!!.toInt()
                    print("INGRESE EL NOMBRE DEL ENCARGADO :")
                    nombrep = readLine().toString()
                    print("INGRESE ID DEL PERSONAL :")
                    idPersonal= readLine().toString()
                    objmaterial.setCantidad(cantidad)
                    objmaterial.setId(idmaterial)
                    objmaterial.setNombre(NombreM)
                    objPersonal.setNombre(nombrep)
                    objPersonal.setId(idPersonal)
                    println(" \n El NUMERO DE CONTROL:  ${ObjAlumno.getNControl()}  \nNOMBRE DEL ALUMNO:  ${ObjAlumno.getNombre()}  \nAPELLIDO PATERNO: ${ObjAlumno.getApellidopat()} \nAPELLIDO MATERNO  : ${ObjAlumno.getApellidomat()} \nCARRERA :${ObjAlumno.getCarrera()} \nNOMBRE DEL AREA : ${objArea.getNombreArea()} \nIDpersonal: ${objPersonal.getId()} \nNombre del area del encargado: ${objPersonal.getNombre()} \nNombre Material : ${objmaterial.getNombre()}  \nCantidad Material: ${objmaterial.getCantidad()}")



                }
                "TESIS" -> {
                    var idmaterial = ""
                    var cantidad = 0
                    var objmaterial: Material = Material(idmaterial, NombreM, cantidad)
                    print(" INGRESE EL ID DEL MATERIAL: ")
                    idmaterial = readLine().toString()
                    print("INGRESE LA CANTIDAD:  ")
                    cantidad = readLine()!!.toInt()
                    print("INGRESE EL NOMBRE DEL ENCARGADO :")
                    nombrep = readLine().toString()
                    print("INGRESE ID DEL PERSONAL :")
                    idPersonal= readLine().toString()
                    objmaterial.setCantidad(cantidad)
                    objmaterial.setId(idmaterial)
                    objmaterial.setNombre(NombreM)
                    objPersonal.setNombre(nombrep)
                    objPersonal.setId(idPersonal)
                    println(" \n El NUMERO DE CONTROL:  ${ObjAlumno.getNControl()}  \nNOMBRE DEL ALUMNO:  ${ObjAlumno.getNombre()}  \nAPELLIDO PATERNO: ${ObjAlumno.getApellidopat()} \nAPELLIDO MATERNO  : ${ObjAlumno.getApellidomat()} \nCARRERA :${ObjAlumno.getCarrera()} \nNOMBRE DEL AREA : ${objArea.getNombreArea()} \nIDpersonal: ${objPersonal.getId()} \nNombre del area del encargado: ${objPersonal.getNombre()} \nNombre Material : ${objmaterial.getNombre()}  \nCantidad Material: ${objmaterial.getCantidad()}")



                }
                "REVISTAS" -> {
                    var idmaterial = ""
                    var cantidad = 0
                    var objmaterial: Material = Material(idmaterial, NombreM, cantidad)
                    print(" INGRESE EL ID DEL MATERIAL: ")
                    idmaterial = readLine().toString()
                    print("INGRESE LA CANTIDAD:  ")
                    cantidad = readLine()!!.toInt()
                    print("INGRESE EL NOMBRE DEL ENCARGADO :")
                    nombrep = readLine().toString()
                    print("INGRESE ID DEL PERSONAL :")
                    idPersonal= readLine().toString()
                    objmaterial.setCantidad(cantidad)
                    objmaterial.setId(idmaterial)
                    objmaterial.setNombre(NombreM)
                    objPersonal.setNombre(nombrep)
                    objPersonal.setId(idPersonal)
                    println(" \n El NUMERO DE CONTROL:  ${ObjAlumno.getNControl()}  \nNOMBRE DEL ALUMNO:  ${ObjAlumno.getNombre()}  \nAPELLIDO PATERNO: ${ObjAlumno.getApellidopat()} \nAPELLIDO MATERNO  : ${ObjAlumno.getApellidomat()} \nCARRERA :${ObjAlumno.getCarrera()} \nNOMBRE DEL AREA : ${objArea.getNombreArea()} \nIDpersonal: ${objPersonal.getId()} \nNombre del area del encargado: ${objPersonal.getNombre()} \nNombre Material : ${objmaterial.getNombre()}  \nCantidad Material: ${objmaterial.getCantidad()}")


                }
            }
        }

                "ALMACEN"-> {
                    objArea.setNombreAre(NombreArea)
                    print("INGRESE EL MATERIAL SOLICITADO : ")
                    NombreM = readLine().toString()
                    when (NombreM) {
                        "PALAS" -> {
                            var idmaterial = ""
                            var cantidad = 0
                            var objmaterial: Material = Material(idmaterial, NombreM, cantidad)
                            print(" INGRESE EL ID DEL MATERIAL: ")
                            idmaterial = readLine().toString()
                            print("INGRESE LA CANTIDAD:  ")
                            cantidad = readLine()!!.toInt()
                            print("INGRESE EL NOMBRE DEL ENCARGADO :")
                            nombrep = readLine().toString()
                            print("INGRESE ID DEL PERSONAL :")
                            idPersonal= readLine().toString()
                            objmaterial.setCantidad(cantidad)
                            objmaterial.setId(idmaterial)
                            objmaterial.setNombre(NombreM)
                            objPersonal.setNombre(nombrep)
                            objPersonal.setId(idPersonal)
                            println(" \n El NUMERO DE CONTROL:  ${ObjAlumno.getNControl()}  \nNOMBRE DEL ALUMNO:  ${ObjAlumno.getNombre()}  \nAPELLIDO PATERNO: ${ObjAlumno.getApellidopat()} \nAPELLIDO MATERNO  : ${ObjAlumno.getApellidomat()} \nCARRERA :${ObjAlumno.getCarrera()} \nNOMBRE DEL AREA : ${objArea.getNombreArea()} \nIDpersonal: ${objPersonal.getId()} \nNombre del area del encargado: ${objPersonal.getNombre()} \nNombre Material : ${objmaterial.getNombre()}  \nCantidad Material: ${objmaterial.getCantidad()}")


                        }
                        "PICOS" -> {
                            var idmaterial = ""
                            var cantidad = 0
                            var objmaterial: Material = Material(idmaterial, NombreM, cantidad)
                            print(" INGRESE EL ID DEL MATERIAL: ")
                            idmaterial = readLine().toString()
                            print("INGRESE LA CANTIDAD:  ")
                            cantidad = readLine()!!.toInt()
                            print("INGRESE EL NOMBRE DEL ENCARGADO :")
                            nombrep = readLine().toString()
                            print("INGRESE ID DEL PERSONAL :")
                            idPersonal= readLine().toString()
                            objmaterial.setCantidad(cantidad)
                            objmaterial.setId(idmaterial)
                            objmaterial.setNombre(NombreM)
                            objPersonal.setNombre(nombrep)
                            objPersonal.setId(idPersonal)
                            println(" \n El NUMERO DE CONTROL:  ${ObjAlumno.getNControl()}  \nNOMBRE DEL ALUMNO:  ${ObjAlumno.getNombre()}  \nAPELLIDO PATERNO: ${ObjAlumno.getApellidopat()} \nAPELLIDO MATERNO  : ${ObjAlumno.getApellidomat()} \nCARRERA :${ObjAlumno.getCarrera()} \nNOMBRE DEL AREA : ${objArea.getNombreArea()} \nIDpersonal: ${objPersonal.getId()} \nNombre del area del encargado: ${objPersonal.getNombre()} \nNombre Material : ${objmaterial.getNombre()}  \nCantidad Material: ${objmaterial.getCantidad()}")



                        }
                        "PALAS" -> {
                            var idmaterial = ""
                            var cantidad = 0
                            var objmaterial: Material = Material(idmaterial, NombreM, cantidad)
                            print(" INGRESE EL ID DEL MATERIAL: ")
                            idmaterial = readLine().toString()
                            print("INGRESE LA CANTIDAD:  ")
                            cantidad = readLine()!!.toInt()
                            print("INGRESE EL NOMBRE DEL ENCARGADO :")
                            nombrep = readLine().toString()
                            print("INGRESE ID DEL PERSONAL :")
                            idPersonal= readLine().toString()
                            objmaterial.setCantidad(cantidad)
                            objmaterial.setId(idmaterial)
                            objmaterial.setNombre(NombreM)
                            objPersonal.setNombre(nombrep)
                            objPersonal.setId(idPersonal)
                            println(" \n El NUMERO DE CONTROL:  ${ObjAlumno.getNControl()}  \nNOMBRE DEL ALUMNO:  ${ObjAlumno.getNombre()}  \nAPELLIDO PATERNO: ${ObjAlumno.getApellidopat()} \nAPELLIDO MATERNO  : ${ObjAlumno.getApellidomat()} \nCARRERA :${ObjAlumno.getCarrera()} \nNOMBRE DEL AREA : ${objArea.getNombreArea()} \nIDpersonal: ${objPersonal.getId()} \nNombre del area del encargado: ${objPersonal.getNombre()} \nNombre Material : ${objmaterial.getNombre()}  \nCantidad Material: ${objmaterial.getCantidad()}")


                        }
                        "BARRETAS" -> {
                            var idmaterial = ""
                            var cantidad = 0
                            var objmaterial: Material = Material(idmaterial, NombreM, cantidad)
                            print(" INGRESE EL ID DEL MATERIAL: ")
                            idmaterial = readLine().toString()
                            print("INGRESE LA CANTIDAD:  ")
                            cantidad = readLine()!!.toInt()
                            print("INGRESE EL NOMBRE DEL ENCARGADO :")
                            nombrep = readLine().toString()
                            print("INGRESE ID DEL PERSONAL :")
                            idPersonal= readLine().toString()
                            objmaterial.setCantidad(cantidad)
                            objmaterial.setId(idmaterial)
                            objmaterial.setNombre(NombreM)
                            objPersonal.setNombre(nombrep)
                            objPersonal.setId(idPersonal)
                            println(" \n El NUMERO DE CONTROL:  ${ObjAlumno.getNControl()}  \nNOMBRE DEL ALUMNO:  ${ObjAlumno.getNombre()}  \nAPELLIDO PATERNO: ${ObjAlumno.getApellidopat()} \nAPELLIDO MATERNO  : ${ObjAlumno.getApellidomat()} \nCARRERA :${ObjAlumno.getCarrera()} \nNOMBRE DEL AREA : ${objArea.getNombreArea()} \nIDpersonal: ${objPersonal.getId()} \nNombre del area del encargado: ${objPersonal.getNombre()} \nNombre Material : ${objmaterial.getNombre()}  \nCantidad Material: ${objmaterial.getCantidad()}")


                        }
                        "MACHETES" -> {
                            var idmaterial = ""
                            var cantidad = 0
                            var objmaterial: Material = Material(idmaterial, NombreM, cantidad)
                            print(" INGRESE EL ID DEL MATERIAL: ")
                            idmaterial = readLine().toString()
                            print("INGRESE LA CANTIDAD:  ")
                            cantidad = readLine()!!.toInt()
                            print("INGRESE EL NOMBRE DEL ENCARGADO :")
                            nombrep = readLine().toString()
                            print("INGRESE ID DEL PERSONAL :")
                            idPersonal= readLine().toString()
                            objmaterial.setCantidad(cantidad)
                            objmaterial.setId(idmaterial)
                            objmaterial.setNombre(NombreM)
                            objPersonal.setNombre(nombrep)
                            objPersonal.setId(idPersonal)
                            println(" \n El NUMERO DE CONTROL:  ${ObjAlumno.getNControl()}  \nNOMBRE DEL ALUMNO:  ${ObjAlumno.getNombre()}  \nAPELLIDO PATERNO: ${ObjAlumno.getApellidopat()} \nAPELLIDO MATERNO  : ${ObjAlumno.getApellidomat()} \nCARRERA :${ObjAlumno.getCarrera()} \nNOMBRE DEL AREA : ${objArea.getNombreArea()} \nIDpersonal: ${objPersonal.getId()} \nNombre del area del encargado: ${objPersonal.getNombre()} \nNombre Material : ${objmaterial.getNombre()}  \nCantidad Material: ${objmaterial.getCantidad()}")


                        }


                    }
                }
            }
        }


