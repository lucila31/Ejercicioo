package com.example.mostrardatos

class Alumno (ncontrol:String, nombre:String, apellidopat:String, apellidomat:String, carrera:String ) {
    private var ncontrol = ncontrol
    private var nombre = nombre
    private var apellidopat = apellidopat
    private var apellidomat = apellidomat
    private var carrera = carrera


    fun setNombre(nom: String) {
        nombre = nom
    }

    fun getNombre(): String {
        return nombre
    }

    fun setNControl(nc: String) {
        ncontrol = nc
    }

    fun getNControl(): String {
        return ncontrol
    }
    fun getApellidopat():String{
        return apellidopat
    }
    fun setApellidopat(apellidoPat: String){
         apellidopat = apellidoPat
    }
    fun getApellidomat():String{
        return apellidomat
    }
    fun setApellidomat(Apellidomat: String){
        apellidomat=Apellidomat
    }
    fun getCarrera():String{
        return carrera
    }
    fun setCarrera(Carrera: String){
        carrera=Carrera
    }

}